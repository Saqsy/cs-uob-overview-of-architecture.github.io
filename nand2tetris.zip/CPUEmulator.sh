#!/usr/bin/env sh

# User's CDPATH can interfere with cd in this script
unset CDPATH

# Get the true name of this script (handles symbolic links)
script="`test -L "$0" && readlink -n "$0" || echo "$0"`"

# Save the original directory where the user invoked the script
dir="$PWD"

# Change directory to where this script is located
cd "`dirname "$script"`"

# Run the Java JAR file from the script's directory
java -jar "bin/CPUEmulator_Bolt_Fork/CPUEmulator-2.6.1.jar"

# Return to the original directory
cd "$dir"

